"""Vanguard LifeStrategy fund calculator."""
