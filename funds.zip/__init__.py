"""Vanguard Multi-Asset Fund Calculation System"""
