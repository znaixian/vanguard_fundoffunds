"""Orchestration module for fund calculation pipeline."""
