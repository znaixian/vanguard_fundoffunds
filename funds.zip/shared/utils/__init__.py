"""Shared utilities module."""
