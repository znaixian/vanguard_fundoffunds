"""Shared validation module for fund calculations."""
