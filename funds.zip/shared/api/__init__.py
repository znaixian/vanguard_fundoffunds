"""Shared API module for FactSet integration."""
